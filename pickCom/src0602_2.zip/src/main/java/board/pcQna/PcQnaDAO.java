package board.pcQna;

import board.BoardDTO;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface PcQnaDAO {
    // 검색 조건에 맞는 게시물의 개수를 반환합니다.
    public int selectCount(Map<String, Object> map);

    // 검색 조건에 맞는 게시물 목록을 반환합니다.
    public List<BoardDTO> selectList(Map<String, Object> map) ;

    // 검색 조건에 맞는 게시물 목록을 반환합니다(페이징 기능 지원).
    public List<BoardDTO> selectListPage(Map<String, Object> map);

    // 게시글 데이터를 받아 DB에 추가합니다.
    public int insertWrite(BoardDTO dto);


    // 지정한 게시물을 찾아 내용을 반환합니다.
    public BoardDTO selectView(String num);

    // 지정한 게시물의 조회수를 1 증가시킵니다.
    public void updateVisitCount(String num);

    // 지정한 게시물을 수정합니다.
    public int updateEdit(BoardDTO dto);

    // 지정한 게시물을 삭제합니다.
    public int deletePost(BoardDTO dto);
}
